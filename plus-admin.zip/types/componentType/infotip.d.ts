declare interface TipSchema {
  label: string
  keys?: string[]
}
