import ContentDetailWrap from './src/ContentDetailWrap.vue'

export { ContentDetailWrap }
