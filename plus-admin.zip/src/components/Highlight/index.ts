import Highlight from './src/Highlight.vue'

export { Highlight }
