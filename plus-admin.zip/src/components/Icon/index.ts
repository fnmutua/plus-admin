import Icon from './src/Icon.vue'

export { Icon }
