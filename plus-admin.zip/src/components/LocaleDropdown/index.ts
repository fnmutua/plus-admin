import LocaleDropdown from './src/LocaleDropdown.vue'

export { LocaleDropdown }
