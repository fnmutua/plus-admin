import 'virtual:svg-icons-register'

import '@purge-icons/generated'
